# Molecule Atlas

A redesigned Streamlit chemistry app with a field-notebook aesthetic.

## Features
- Distinctive specimen-card layout and green/ivory design
- Compound library for glucose, sucrose, adenine, guanine, and aniline
- Custom SMILES mode
- Side-by-side compound comparison
- 2D structures, input/canonical SMILES, bond census
- RDKit molecular descriptors and qualitative bond-angle notes
- Functional-group watchlist, isomer context, student identity fields
- Downloadable PDF dossier and JSON data

## Run on Windows
1. Install Python 3.11 or 3.12 from https://www.python.org/downloads/windows/
2. Extract the folder.
3. Open Command Prompt in this folder.
4. Run `python -m pip install -r requirements.txt`
5. Run `python -m streamlit run app.py`
6. Open the local URL printed in the terminal, usually http://localhost:8501

## Deploy online
Push `app.py` and `requirements.txt` to GitHub, then deploy at https://share.streamlit.io/.

## Chemistry note
RDKit descriptors are calculated from SMILES. Melting/boiling points and isomer notes are educational references, not measured values or exhaustive isomer enumeration. Verify stereochemistry and physical properties against trusted sources before formal submission.
